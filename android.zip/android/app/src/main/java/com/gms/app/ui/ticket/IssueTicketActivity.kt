package com.gms.app.ui.ticket

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gms.app.R
import com.gms.app.SessionManager
import com.gms.app.db.GmsDatabase
import com.gms.app.model.Ticket
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class IssueTicketActivity : AppCompatActivity() {

    private lateinit var etVisitorName: EditText
    private lateinit var etVisitorPhone: EditText
    private lateinit var spinnerType: Spinner
    private lateinit var spinnerZone: Spinner
    private lateinit var etOriginalPrice: EditText
    private lateinit var etDiscount: EditText
    private lateinit var etFinalPrice: EditText
    private lateinit var etReason: EditText
    private lateinit var btnIssue: Button
    private lateinit var tvCacheBadge: TextView
    private lateinit var layoutReason: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_issue_ticket)

        etVisitorName  = findViewById(R.id.etVisitorName)
        etVisitorPhone = findViewById(R.id.etVisitorPhone)
        spinnerType    = findViewById(R.id.spinnerVisitorType)
        spinnerZone    = findViewById(R.id.spinnerZone)
        etOriginalPrice = findViewById(R.id.etOriginalPrice)
        etDiscount     = findViewById(R.id.etDiscount)
        etFinalPrice   = findViewById(R.id.etFinalPrice)
        etReason       = findViewById(R.id.etReason)
        btnIssue       = findViewById(R.id.btnIssueTicket)
        tvCacheBadge   = findViewById(R.id.tvCacheBadge)
        layoutReason   = findViewById(R.id.layoutReason)

        // Visitor type spinner
        val types = arrayOf("Paid Visitor (adult)", "Free", "Room Guest")
        spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
        spinnerType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                layoutReason.visibility = if (pos == 2) View.VISIBLE else View.GONE
                if (pos == 1) { etOriginalPrice.setText("0"); etFinalPrice.setText("0") }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Zone spinner — filter by user access_area
        val user = SessionManager.getUser(this)
        val zones = when (user?.accessArea) {
            "gate" -> arrayOf("Resort Gate")
            "pool" -> arrayOf("Swimming Pool")
            else   -> arrayOf("Resort Gate", "Swimming Pool")
        }
        spinnerZone.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, zones)

        // Auto-calculate final price
        etDiscount.setOnFocusChangeListener { _, _ -> calcFinalPrice() }

        btnIssue.setOnClickListener { saveTicket() }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Issue Ticket"
    }

    private fun calcFinalPrice() {
        val orig     = etOriginalPrice.text.toString().toDoubleOrNull() ?: 0.0
        val discount = etDiscount.text.toString().toDoubleOrNull() ?: 0.0
        etFinalPrice.setText(String.format("%.2f", maxOf(0.0, orig - discount)))
    }

    private fun typeValue(pos: Int) = when (pos) {
        0 -> "adult"
        1 -> "free"
        2 -> "room_guest"
        else -> "adult"
    }

    private fun zoneValue(label: String) = when (label) {
        "Swimming Pool" -> "swimming_pool"
        else            -> "resort_gate"
    }

    private fun generateTicketNumber(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rand  = (1..7).map { chars.random() }.joinToString("")
        return "TICK-$rand"
    }

    private fun saveTicket() {
        val name  = etVisitorName.text.toString().trim().ifEmpty { "Walk-in" }
        val phone = etVisitorPhone.text.toString().trim()
        val orig  = etOriginalPrice.text.toString().toDoubleOrNull() ?: 0.0
        val disc  = etDiscount.text.toString().toDoubleOrNull() ?: 0.0
        val final = etFinalPrice.text.toString().toDoubleOrNull() ?: maxOf(0.0, orig - disc)
        val type  = typeValue(spinnerType.selectedItemPosition)
        val zone  = zoneValue(spinnerZone.selectedItem.toString())
        val reason = etReason.text.toString().trim()
        val user  = SessionManager.getUser(this)

        if (phone.isEmpty()) {
            Toast.makeText(this, "Phone number দাও", Toast.LENGTH_SHORT).show()
            return
        }

        val ticket = Ticket(
            ticketNumber  = generateTicketNumber(),
            visitorName   = name,
            visitorPhone  = phone,
            visitorType   = type,
            zone          = zone,
            originalPrice = orig,
            discount      = disc,
            finalPrice    = final,
            reason        = reason,
            issuedBy      = user?.userId ?: 0,
            createdAt     = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
            isSynced      = false
        )

        lifecycleScope.launch {
            val dao = GmsDatabase.getInstance(this@IssueTicketActivity).ticketDao()
            dao.insert(ticket)
            Toast.makeText(
                this@IssueTicketActivity,
                "✓ Ticket ${ticket.ticketNumber} saved locally",
                Toast.LENGTH_LONG
            ).show()
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
