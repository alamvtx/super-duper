package com.gms.app.ui.login

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gms.app.R
import com.gms.app.SessionManager
import com.gms.app.api.ApiClient
import com.gms.app.api.LoginRequest
import com.gms.app.model.User
import com.gms.app.ui.home.HomeActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvError: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvOfflineBadge: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Already logged in → skip to Home
        if (SessionManager.isLoggedIn(this)) {
            goHome()
            return
        }

        setContentView(R.layout.activity_login)

        etUsername    = findViewById(R.id.etUsername)
        etPassword    = findViewById(R.id.etPassword)
        btnLogin      = findViewById(R.id.btnLogin)
        tvError       = findViewById(R.id.tvError)
        progressBar   = findViewById(R.id.progressBar)
        tvOfflineBadge = findViewById(R.id.tvOfflineBadge)

        updateConnBadge()

        btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateConnBadge() {
        if (isOnline()) {
            tvOfflineBadge.visibility = View.GONE
        } else {
            tvOfflineBadge.visibility = View.VISIBLE
            tvOfflineBadge.text = "⚠ Offline — Cached login only"
        }
    }

    private fun attemptLogin() {
        val username = etUsername.text.toString().trim()
        val password = etPassword.text.toString().trim()
        tvError.visibility = View.GONE

        if (username.isEmpty() || password.isEmpty()) {
            showError("Username ও Password দাও")
            return
        }

        setLoading(true)

        lifecycleScope.launch {
            try {
                if (isOnline()) {
                    // ── Live API login ──────────────────────────────────────
                    val response = ApiClient.service.login(LoginRequest(username, password))
                    if (response.isSuccessful && response.body()?.status == "success") {
                        val body = response.body()!!
                        val user = User(
                            userId     = body.user_id,
                            userName   = body.user_name,
                            username   = body.username,
                            userRole   = body.user_role,
                            accessArea = body.access_area
                        )
                        SessionManager.saveUser(this@LoginActivity, user)
                        goHome()
                    } else {
                        showError("Invalid username or password")
                    }
                } else {
                    // ── Offline: not supported for first login ──────────────
                    showError("প্রথমবার login করতে internet দরকার")
                }
            } catch (e: Exception) {
                showError("Connection error: ${e.localizedMessage}")
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        btnLogin.isEnabled = !loading
        btnLogin.text = if (loading) "Logging in..." else "Sign In"
    }

    private fun showError(msg: String) {
        tvError.text = msg
        tvError.visibility = View.VISIBLE
    }

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
