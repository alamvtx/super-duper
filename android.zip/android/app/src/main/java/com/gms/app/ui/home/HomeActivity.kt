package com.gms.app.ui.home

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.gms.app.R
import com.gms.app.SessionManager
import com.gms.app.api.ApiClient
import com.gms.app.api.ApiClient.toPayload
import com.gms.app.db.GmsDatabase
import com.gms.app.ui.login.LoginActivity
import com.gms.app.ui.ticket.IssueTicketActivity
import com.gms.app.ui.history.HistoryActivity
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {

    private lateinit var tvWelcome: TextView
    private lateinit var tvUserRole: TextView
    private lateinit var tvConnStatus: TextView
    private lateinit var tvTotalCount: TextView
    private lateinit var tvPendingCount: TextView
    private lateinit var btnIssueTicket: Button
    private lateinit var btnSync: Button
    private lateinit var btnHistory: Button
    private lateinit var btnLogout: Button
    private lateinit var progressSync: ProgressBar
    private lateinit var tvSyncStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        tvWelcome      = findViewById(R.id.tvWelcome)
        tvUserRole     = findViewById(R.id.tvUserRole)
        tvConnStatus   = findViewById(R.id.tvConnStatus)
        tvTotalCount   = findViewById(R.id.tvTotalCount)
        tvPendingCount = findViewById(R.id.tvPendingCount)
        btnIssueTicket = findViewById(R.id.btnIssueTicket)
        btnSync        = findViewById(R.id.btnSync)
        btnHistory     = findViewById(R.id.btnHistory)
        btnLogout      = findViewById(R.id.btnLogout)
        progressSync   = findViewById(R.id.progressSync)
        tvSyncStatus   = findViewById(R.id.tvSyncStatus)

        val user = SessionManager.getUser(this)
        tvWelcome.text  = "স্বাগতম, ${user?.userName ?: "Operator"}"
        tvUserRole.text = "${user?.userRole?.uppercase()} · ${user?.accessArea?.uppercase()}"

        updateConnStatus()
        refreshCounts()

        btnIssueTicket.setOnClickListener {
            startActivity(Intent(this, IssueTicketActivity::class.java))
        }

        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        btnSync.setOnClickListener { doSync() }

        btnLogout.setOnClickListener {
            SessionManager.logout(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        updateConnStatus()
        refreshCounts()
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun updateConnStatus() {
        if (isOnline()) {
            tvConnStatus.text = "🟢 Online"
            tvConnStatus.setTextColor(getColor(R.color.color_online))
        } else {
            tvConnStatus.text = "🟡 Offline — Local Cache Mode"
            tvConnStatus.setTextColor(getColor(R.color.color_offline))
        }
    }

    private fun refreshCounts() {
        lifecycleScope.launch {
            val dao = GmsDatabase.getInstance(this@HomeActivity).ticketDao()
            tvTotalCount.text   = dao.totalCount().toString()
            tvPendingCount.text = dao.pendingCount().toString()
        }
    }

    private fun doSync() {
        if (!isOnline()) {
            Toast.makeText(this, "Internet নেই! Sync করা যাবে না।", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            val dao     = GmsDatabase.getInstance(this@HomeActivity).ticketDao()
            val pending = dao.getPending()

            if (pending.isEmpty()) {
                Toast.makeText(this@HomeActivity, "Sync করার কিছু নেই।", Toast.LENGTH_SHORT).show()
                return@launch
            }

            setSyncLoading(true, "Syncing ${pending.size} records...")

            try {
                val payload  = pending.map { it.toPayload() }
                val response = ApiClient.service.bulkSync(payload)

                if (response.isSuccessful && response.body()?.status == "success") {
                    // ✅ Server confirmed → mark local records as synced
                    val numbers = pending.map { it.ticketNumber }
                    dao.markSynced(numbers)

                    val msg = response.body()?.message ?: "${pending.size} tickets synced!"
                    tvSyncStatus.text = "✓ $msg"
                    Toast.makeText(this@HomeActivity, msg, Toast.LENGTH_LONG).show()
                    refreshCounts()
                } else {
                    tvSyncStatus.text = "Sync failed. Try again."
                    Toast.makeText(this@HomeActivity, "Sync failed!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                tvSyncStatus.text = "Error: ${e.localizedMessage}"
                Toast.makeText(this@HomeActivity, "Connection error!", Toast.LENGTH_SHORT).show()
            } finally {
                setSyncLoading(false)
            }
        }
    }

    private fun setSyncLoading(loading: Boolean, msg: String = "") {
        progressSync.visibility = if (loading) View.VISIBLE else View.GONE
        btnSync.isEnabled = !loading
        btnSync.text = if (loading) "Syncing..." else "☁ Sync to Cloud"
        if (msg.isNotEmpty()) tvSyncStatus.text = msg
    }
}
