package com.gms.app.db

import android.content.Context
import androidx.room.*
import com.gms.app.model.Ticket

// ── DAO ──────────────────────────────────────────────────────────────────────

@Dao
interface TicketDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(ticket: Ticket): Long

    @Query("SELECT * FROM tickets ORDER BY localId DESC")
    suspend fun getAll(): List<Ticket>

    @Query("SELECT * FROM tickets WHERE isSynced = 0 ORDER BY localId ASC")
    suspend fun getPending(): List<Ticket>

    @Query("SELECT COUNT(*) FROM tickets WHERE isSynced = 0")
    suspend fun pendingCount(): Int

    @Query("SELECT COUNT(*) FROM tickets")
    suspend fun totalCount(): Int

    @Query("UPDATE tickets SET isSynced = 1 WHERE ticketNumber IN (:numbers)")
    suspend fun markSynced(numbers: List<String>)

    @Query("SELECT * FROM tickets ORDER BY localId DESC LIMIT 20")
    suspend fun getRecent(): List<Ticket>
}

// ── Database ──────────────────────────────────────────────────────────────────

@Database(entities = [Ticket::class], version = 1, exportSchema = false)
abstract class GmsDatabase : RoomDatabase() {

    abstract fun ticketDao(): TicketDao

    companion object {
        @Volatile private var INSTANCE: GmsDatabase? = null

        fun getInstance(context: Context): GmsDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    GmsDatabase::class.java,
                    "gms_offline.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
