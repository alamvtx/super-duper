package com.gms.app.api

import com.gms.app.model.Ticket
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

// ── Request / Response Models ────────────────────────────────────────────────

data class LoginRequest(val username: String, val password: String)

data class LoginResponse(
    val status: String,
    val message: String,
    val user_id: Int = 0,
    val user_name: String = "",
    val username: String = "",
    val user_role: String = "",
    val access_area: String = ""
)

data class SyncResponse(
    val status: String,
    val message: String,
    val synced: Int = 0,
    val skipped: Int = 0
)

data class TicketSyncPayload(
    val ticket_number: String,
    val visitor_name: String,
    val visitor_phone: String,
    val visitor_type: String,
    val zone: String,
    val original_price: Double,
    val discount: Double,
    val final_price: Double,
    val reason: String,
    val issued_by: Int,
    val created_at: String
)

// ── Retrofit Interface ────────────────────────────────────────────────────────

interface GmsApiService {

    @POST("api/login.php")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("api/bulk_sync.php")
    suspend fun bulkSync(@Body tickets: List<TicketSyncPayload>): Response<SyncResponse>
}

// ── Singleton Client ──────────────────────────────────────────────────────────

object ApiClient {

    // ⚠️ এখানে তোমার আসল URL দাও
    private const val BASE_URL = "https://soft.deshhoster.com/gms/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    val service: GmsApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttp)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GmsApiService::class.java)
    }

    // Ticket → Payload converter
    fun Ticket.toPayload() = TicketSyncPayload(
        ticket_number  = ticketNumber,
        visitor_name   = visitorName,
        visitor_phone  = visitorPhone,
        visitor_type   = visitorType,
        zone           = zone,
        original_price = originalPrice,
        discount       = discount,
        final_price    = finalPrice,
        reason         = reason,
        issued_by      = issuedBy,
        created_at     = createdAt
    )
}
