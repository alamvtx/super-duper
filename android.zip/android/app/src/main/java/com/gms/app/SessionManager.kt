package com.gms.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.gms.app.model.User

object SessionManager {

    private const val PREF_FILE = "gms_session"
    private const val KEY_USER_ID     = "user_id"
    private const val KEY_USER_NAME   = "user_name"
    private const val KEY_USERNAME    = "username"
    private const val KEY_USER_ROLE   = "user_role"
    private const val KEY_ACCESS_AREA = "access_area"
    private const val KEY_LOGGED_IN   = "is_logged_in"

    private fun prefs(context: Context) = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context, PREF_FILE, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback to regular SharedPreferences if encryption fails
        context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
    }

    fun saveUser(context: Context, user: User) {
        prefs(context).edit().apply {
            putBoolean(KEY_LOGGED_IN, true)
            putInt(KEY_USER_ID, user.userId)
            putString(KEY_USER_NAME, user.userName)
            putString(KEY_USERNAME, user.username)
            putString(KEY_USER_ROLE, user.userRole)
            putString(KEY_ACCESS_AREA, user.accessArea)
            apply()
        }
    }

    fun getUser(context: Context): User? {
        val p = prefs(context)
        if (!p.getBoolean(KEY_LOGGED_IN, false)) return null
        return User(
            userId     = p.getInt(KEY_USER_ID, 0),
            userName   = p.getString(KEY_USER_NAME, "") ?: "",
            username   = p.getString(KEY_USERNAME, "") ?: "",
            userRole   = p.getString(KEY_USER_ROLE, "staff") ?: "staff",
            accessArea = p.getString(KEY_ACCESS_AREA, "gate") ?: "gate"
        )
    }

    fun isLoggedIn(context: Context) =
        prefs(context).getBoolean(KEY_LOGGED_IN, false)

    fun logout(context: Context) {
        prefs(context).edit().clear().apply()
    }
}
