package com.gms.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true)
    val localId: Int = 0,
    val ticketNumber: String,
    val visitorName: String,
    val visitorPhone: String,
    val visitorType: String,     // adult, free, room_guest
    val zone: String,            // resort_gate, swimming_pool
    val originalPrice: Double,
    val discount: Double,
    val finalPrice: Double,
    val reason: String,
    val issuedBy: Int,
    val createdAt: String,
    val isSynced: Boolean = false
)

data class User(
    val userId: Int,
    val userName: String,
    val username: String,
    val userRole: String,   // admin, manager, staff
    val accessArea: String  // gate, pool, both
)
