package com.gms.app.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gms.app.R
import com.gms.app.db.GmsDatabase
import com.gms.app.model.Ticket
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val rv = findViewById<RecyclerView>(R.id.rvTickets)
        rv.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val tickets = GmsDatabase.getInstance(this@HistoryActivity).ticketDao().getAll()
            rv.adapter = TicketAdapter(tickets)
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Ticket History"
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class TicketAdapter(private val items: List<Ticket>) :
    RecyclerView.Adapter<TicketAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvTicketNum: TextView  = view.findViewById(R.id.tvTicketNum)
        val tvName: TextView       = view.findViewById(R.id.tvVisitorName)
        val tvMeta: TextView       = view.findViewById(R.id.tvMeta)
        val tvPrice: TextView      = view.findViewById(R.id.tvPrice)
        val tvSyncBadge: TextView  = view.findViewById(R.id.tvSyncBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_ticket, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val t = items[position]
        holder.tvTicketNum.text  = t.ticketNumber
        holder.tvName.text       = t.visitorName
        holder.tvMeta.text       = "${t.visitorType.replace("_", " ")} · ${t.zone.replace("_", " ")} · ${t.createdAt.take(16)}"
        holder.tvPrice.text      = "৳${String.format("%.2f", t.finalPrice)}"
        holder.tvSyncBadge.text  = if (t.isSynced) "Synced" else "Pending"
        holder.tvSyncBadge.setBackgroundResource(
            if (t.isSynced) R.drawable.badge_synced else R.drawable.badge_pending
        )
    }
}
